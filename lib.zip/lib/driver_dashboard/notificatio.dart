import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:practice/driver_dashboard/feedback.dart';

class NotificationListener extends StatefulWidget {
  const NotificationListener({super.key});

  @override
  State<NotificationListener> createState() => _NotificationListenerState();
}

class _NotificationListenerState extends State<NotificationListener> {
  bool _isNavigating = false;

  void _navigateToRatings(BuildContext context, String driverId) {
    if (_isNavigating) return; // Prevent double navigation

    setState(() {
      _isNavigating = true;
    });

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => RatingsAndReviewsScreen(driverId: driverId),
      ),
    ).then((_) {
      setState(() {
        _isNavigating = false; // Reset navigation flag
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('notifications').doc('driver123').snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData || snapshot.data?.data() == null) {
          return const Center(child: Text('No notifications yet.'));
        }

        final notification = snapshot.data!.data() as Map<String, dynamic>;

        if (notification['title'] == 'Driver Arrived') {
          Future.delayed(Duration.zero, () {
            if (!_isNavigating) {
              _navigateToRatings(context, 'driver123');
            }
          });
        }

        return const Center(child: Text('Listening for notifications...'));
      },
    );
  }
}
