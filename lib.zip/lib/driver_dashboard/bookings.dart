import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:practice/driver_dashboard/location.dart';

class BookedTodayScreen extends StatelessWidget {
  const BookedTodayScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bookings'),
        backgroundColor: Colors.orange,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('bookings')
            .orderBy('timestamp', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No bookings found'));
          }

          final bookings = snapshot.data!.docs;

          return ListView.builder(
            itemCount: bookings.length,
            itemBuilder: (context, index) {
              final booking = bookings[index].data() as Map<String, dynamic>;

              return Card(
                margin:
                    const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundImage: booking['profileImage'] != null
                        ? NetworkImage(booking['profileImage'])
                        : const AssetImage('assets/placeholder.png')
                            as ImageProvider,
                  ),
                  title: Text(booking['passengerName'] ?? 'Unknown Passenger'),
                  subtitle: Text(
                    'Pick-up: ${booking['pickUp']}\nDrop-off: ${booking['dropOff']}',
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.location_on, color: Colors.blue),
                    onPressed: () {
                      // Navigate to Location Screen with booking details
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              LocationScreen(booking: booking),
                        ),
                      );
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Navigate to Trip History Screen
          Navigator.pushNamed(context, '/tripHistory');
        },
        child: const Icon(Icons.history),
        backgroundColor: Colors.orange,
      ),
    );
  }
}
