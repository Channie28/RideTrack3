import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:practice/driver_dashboard/bookings.dart';
import 'package:practice/driver_dashboard/driver_history.dart';
import 'package:practice/driver_dashboard/feedback.dart';
import 'package:practice/driver_dashboard/location.dart';
import 'dart:io';
import 'driver_profile.dart';

class RideTrackApp extends StatefulWidget {
  final String welcomeMessage;

  const RideTrackApp({super.key, required this.welcomeMessage});

  @override
  _RideTrackAppState createState() => _RideTrackAppState();
}

class _RideTrackAppState extends State<RideTrackApp> {
  int _currentIndex = 0;

  late List<Widget> _screens;

  @override
  void initState() {
    super.initState();
    _screens = [
      HomedriverScreen(welcomeMessage: widget.welcomeMessage),
      LocationScreen(
        booking: {},
      ),
      NotificationListener(),
      ProfileScreen(), // Define your profile screen here
    ];
  }

  void _onNavBarTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: Colors.orange,
        unselectedItemColor: Colors.grey,
        onTap: _onNavBarTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
              icon: Icon(Icons.location_on), label: 'Location'),
          BottomNavigationBarItem(
              icon: Icon(Icons.notifications), label: 'Notification'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomedriverScreen extends StatefulWidget {
  final String welcomeMessage;

  const HomedriverScreen({super.key, required this.welcomeMessage});

  @override
  _HomedriverScreenState createState() => _HomedriverScreenState();
}

class _HomedriverScreenState extends State<HomedriverScreen> {
  File? _profileImage;

  Future<void> _pickProfileImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      setState(() {
        _profileImage = File(image.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Driver Dashboard'),
        backgroundColor: Colors.orange,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                GestureDetector(
                  onTap: _pickProfileImage,
                  child: CircleAvatar(
                    radius: 50,
                    backgroundImage: _profileImage == null
                        ? const AssetImage('assets/profile.jpg')
                        : FileImage(_profileImage!) as ImageProvider,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  widget.welcomeMessage,
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          Expanded(
            child: GridView.count(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              padding: const EdgeInsets.all(10),
              childAspectRatio: 1.2,
              children: [
                _buildGridButton('Ride History', Icons.history, () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => TripHistoryScreen()),
                  );
                }),
                _buildGridButton('Bookings', Icons.monetization_on, () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => BookedTodayScreen()),
                  );
                }),
                _buildGridButton('Feedbacks', Icons.feedback, () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => RatingsAndReviewsScreen(
                              driverId: 'driverId123',
                            )),
                  );
                }),
                _buildGridButton('Settings', Icons.settings, () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => RouteSettings()),
                  );
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGridButton(String title, IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        elevation: 5,
        color: Colors.orange[100],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: Colors.orange),
            const SizedBox(height: 10),
            Text(
              title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}

// Profile Screen with Image Pick and Save

// Ride History Screen

// Book Ride Screen

// Earnings Screen

// Feedbacks Screen

// RouteSettings Screen
class RouteSettings extends StatelessWidget {
  const RouteSettings({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: const Center(child: Text('Settings Page')),
    );
  }
}

// Notification Screen
class NotificationListener extends StatefulWidget {
  const NotificationListener({super.key});

  @override
  State<NotificationListener> createState() => _NotificationListenerState();
}

class _NotificationListenerState extends State<NotificationListener> {
  bool _isNavigating = false;

  void _navigateToRatings(BuildContext context, String driverId) {
    if (_isNavigating) return; // Prevent double navigation

    setState(() {
      _isNavigating = true;
    });

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => RatingsAndReviewsScreen(driverId: driverId),
      ),
    ).then((_) {
      setState(() {
        _isNavigating = false; // Reset navigation flag
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance
          .collection('notifications')
          .doc('driver123')
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData || snapshot.data?.data() == null) {
          return const Center(child: Text('No notifications yet.'));
        }

        final notification = snapshot.data!.data() as Map<String, dynamic>;

        if (notification['title'] == 'Driver Arrived') {
          Future.delayed(Duration.zero, () {
            if (!_isNavigating) {
              _navigateToRatings(context, 'driver123');
            }
          });
        }

        return const Center(child: Text('Listening for notifications...'));
      },
    );
  }
}
