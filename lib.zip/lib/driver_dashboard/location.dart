import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class LocationScreen extends StatelessWidget {
  final Map<String, dynamic> booking; // Required parameter

  const LocationScreen({super.key, required this.booking});

  @override
  Widget build(BuildContext context) {
    Future.delayed(Duration.zero, () async {
      // Add booking to trip history automatically after navigating to this screen
      final querySnapshot = await FirebaseFirestore.instance
          .collection('tripHistory')
          .where('from', isEqualTo: booking['pickUp'])
          .where('to', isEqualTo: booking['dropOff'])
          .where('passengerName', isEqualTo: booking['passengerName'])
          .get();

      if (querySnapshot.docs.isEmpty) {
        // If the booking doesn't exist, add it to the trip history
        await FirebaseFirestore.instance.collection('tripHistory').add({
          'from': booking['pickUp'],
          'to': booking['dropOff'],
          'date': DateTime.now().toString().split(' ')[0],
          'time': TimeOfDay.now().format(context),
          'passengerName': booking['passengerName'],
          'timestamp': FieldValue.serverTimestamp(),
        });
      }

      // Notify the passenger that the driver has arrived
      await FirebaseFirestore.instance.collection('notifications').doc('passengerId').set({
        'title': 'Driver Arrived',
        'message': 'Your driver is waiting at the location.',
        'timestamp': FieldValue.serverTimestamp(),
        'isRead': false, // To track unread notifications
      });
    });

    return Scaffold(
      appBar: AppBar(
        title: const Text('Temporary Location'),
        backgroundColor: Colors.blue,
      ),
      body: const Center(
        child: Text(
          'You have arrived at the temporary location.',
          style: TextStyle(fontSize: 18),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Navigate back to the bookings screen
          Navigator.pop(context);
        },
        child: const Icon(Icons.arrow_back),
        backgroundColor: Colors.blue,
      ),
    );
  }
}
