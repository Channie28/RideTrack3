import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'custom_button.dart';
import 'custom_textfield.dart';
import 'driver_login.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController plateNumberController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();

  bool isLoading = false;
  bool termsAccepted = false;

  void _showTermsDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text("Accept Terms & Conditions"),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    "By using the RideTrack app, you agree to comply with and be bound by the following terms and conditions. If you do not agree with any part of these terms, you must not use the app. We are committed to protecting your privacy. Your personal data will be used only for providing and improving our services as outlined in our Privacy Policy. RideTrack will not be liable for any direct, indirect, incidental, or consequential damages arising from the use or inability to use the app. We reserve the right to update these terms at any time. Continued use of the app constitutes acceptance of any changes.",
                  ),
                  Row(
                    children: [
                      Checkbox(
                        value: termsAccepted,
                        onChanged: (bool? value) {
                          setState(() {
                            termsAccepted = value ?? false;
                          });
                        },
                      ),
                      const Text("I accept the terms & conditions"),
                    ],
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Cancel"),
                ),
                TextButton(
                  onPressed: termsAccepted
                      ? () {
                          Navigator.pop(context);
                          _register(context);
                        }
                      : null,
                  child: const Text("Proceed"),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _register(BuildContext context) async {
    if (nameController.text.isEmpty ||
        plateNumberController.text.isEmpty ||
        emailController.text.isEmpty ||
        passwordController.text.isEmpty) {
      _showMessageDialog(
        context,
        title: 'Error',
        message: 'All fields must be filled!',
      );
    } else if (passwordController.text != confirmPasswordController.text) {
      _showMessageDialog(
        context,
        title: 'Error',
        message: 'Passwords do not match!',
      );
    } else {
      setState(() {
        isLoading = true;
      });

      try {
        UserCredential userCredential =
            await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: emailController.text,
          password: passwordController.text,
        );

        User? user = userCredential.user;
        if (user != null) {
          await FirebaseFirestore.instance
              .collection('users')
              .doc(user.uid)
              .set({
            'name': nameController.text,
            'plateNumber': plateNumberController.text,
            'email': emailController.text,
            'registrationDate': Timestamp.now(),
          });

          await user.sendEmailVerification();

          _showMessageDialog(
            context,
            title: 'Success',
            message:
                'Registration successful! Please check your email to verify your account.',
            isSuccess: true,
          );
        }
      } catch (e) {
        _showMessageDialog(
          context,
          title: 'Error',
          message: 'Failed to register: ${e.toString()}',
        );
      } finally {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  void _showMessageDialog(BuildContext context,
      {required String title,
      required String message,
      bool isSuccess = false}) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context); // Close dialog
              if (isSuccess) {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                );
              }
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Register'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              CustomTextField(
                label: 'Name',
                hint: 'Enter your full name',
                controller: nameController,
              ),
              const SizedBox(height: 16),
              CustomTextField(
                label: 'Plate Number',
                hint: 'Enter your plate number',
                controller: plateNumberController,
              ),
              const SizedBox(height: 16),
              CustomTextField(
                label: 'Email',
                hint: 'Enter your email',
                controller: emailController,
              ),
              const SizedBox(height: 16),
              CustomTextField(
                label: 'Password',
                hint: 'Enter your password',
                isPassword: true,
                controller: passwordController,
              ),
              const SizedBox(height: 16),
              CustomTextField(
                label: 'Confirm Password',
                hint: 'Re-enter your password',
                isPassword: true,
                controller: confirmPasswordController,
              ),
              const SizedBox(height: 32),
              isLoading
                  ? const Center(
                      child: CircularProgressIndicator(
                        color: Colors.orange,
                      ),
                    )
                  : CustomButton(
                      text: 'Register',
                      onPressed: () => _showTermsDialog(context),
                    ),
              const SizedBox(height: 20),
              TextButton(
                onPressed: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                ),
                child: const Text(
                  "Already have an account? Login",
                  style: TextStyle(color: Colors.orange),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
