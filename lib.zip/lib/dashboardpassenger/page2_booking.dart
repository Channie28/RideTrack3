import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Paga2Booking extends StatefulWidget {
  final String driverName;
  final String plateNumber;
  final String contactNumber;
  final String profileImage;

  const Paga2Booking({
    super.key,
    required this.driverName,
    required this.plateNumber,
    required this.contactNumber,
    required this.profileImage,
  });

  @override
  _Paga2BookingState createState() => _Paga2BookingState();
}

class _Paga2BookingState extends State<Paga2Booking> {
  final TextEditingController _pickUpController = TextEditingController();
  final TextEditingController _dropOffController = TextEditingController();
  final TextEditingController _passengerNameController =
      TextEditingController();

  Future<void> _submitBooking() async {
    if (_pickUpController.text.isEmpty ||
        _dropOffController.text.isEmpty ||
        _passengerNameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill in all fields')),
      );
      return;
    }

    try {
      final bookingDetails = {
        'driverName': widget.driverName,
        'plateNumber': widget.plateNumber,
        'contactNumber': widget.contactNumber,
        'profileImage': widget.profileImage,
        'passengerName': _passengerNameController.text,
        'pickUp': _pickUpController.text,
        'dropOff': _dropOffController.text,
        'timestamp': FieldValue.serverTimestamp(),
      };

      await FirebaseFirestore.instance
          .collection('bookings')
          .add(bookingDetails);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Booking submitted successfully')),
      );

      _pickUpController.clear();
      _dropOffController.clear();
      _passengerNameController.clear();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(16.0),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.orange.shade50, Colors.orange.shade100],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
            child: Column(
              children: [
                const SizedBox(height: 20),
                TextField(
                  controller: _passengerNameController,
                  decoration: const InputDecoration(
                    labelText: 'Passenger Name',
                    prefixIcon: Icon(Icons.person),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: _pickUpController,
                  decoration: const InputDecoration(
                    labelText: 'Pick-up Location',
                    prefixIcon: Icon(Icons.place),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: _dropOffController,
                  decoration: const InputDecoration(
                    labelText: 'Drop-off Location',
                    prefixIcon: Icon(Icons.pin_drop),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _submitBooking,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  child: const Text('Submit Booking'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
