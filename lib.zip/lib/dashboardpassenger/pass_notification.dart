import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:practice/dashboardpassenger/notif_reusable.dart';

class ExampleScreen extends StatelessWidget {
  const ExampleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('RideTrack Notifications'),
        backgroundColor: Colors.orange,
      ),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance
            .collection('notifications') // Assuming notifications collection
            .doc('passengerId') // Replace with actual passenger ID
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData || snapshot.data?.data() == null) {
            return const Center(
              child: Text('No notifications yet'),
            );
          }

          final notification = snapshot.data!.data() as Map<String, dynamic>;
          if (notification['title'] == 'Driver Arrived') {
            Future.delayed(Duration.zero, () {
              showModalBottomSheet(
                context: context,
                isDismissible: true,
                backgroundColor: Colors.transparent,
                builder: (_) => RideTrackNotification(
                  title: notification['title'],
                  message: notification['message'],
                  icon: Icons.directions_car,
                  onActionPressed: () {
                    // Mark notification as read in Firestore
                    FirebaseFirestore.instance
                        .collection('notifications')
                        .doc('passengerId')
                        .update({'isRead': true});
                  },
                ),
              );
            });
          }

          return const Center(
            child: Text('Listening for notifications...'),
          );
        },
      ),
    );
  }
}
