import 'package:flutter/material.dart';
import 'package:practice/dashboardpassenger/location_passenger.dart';

class RideTrackNotification extends StatefulWidget {
  final String title;
  final String message;
  final IconData icon;
  final VoidCallback onActionPressed;

  const RideTrackNotification({
    required this.title,
    required this.message,
    required this.icon,
    required this.onActionPressed,
    super.key,
  });

  @override
  _RideTrackNotificationState createState() => _RideTrackNotificationState();
}

class _RideTrackNotificationState extends State<RideTrackNotification> {
  bool _isNavigating = false; // Flag to prevent double navigation

  void _handleNavigation(BuildContext context) {
    if (_isNavigating) return;

    setState(() {
      _isNavigating = true;
    });

    widget.onActionPressed(); // Perform action before navigation

    Navigator.pop(context); // Close the notification modal

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const PassLocationScreen(
          tripId: '',
        ),
      ),
    ).then((_) {
      setState(() {
        _isNavigating = false; // Reset flag when navigation completes
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Icon(widget.icon, size: 40, color: Colors.orange),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      widget.message,
                      style: const TextStyle(fontSize: 16),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () => _handleNavigation(context),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
            child: const Text('Close & View Location'),
          ),
        ],
      ),
    );
  }
}
