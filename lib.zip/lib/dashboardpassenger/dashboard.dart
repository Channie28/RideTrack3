import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:practice/dashboardpassenger/history_pass.dart';
import 'package:practice/dashboardpassenger/location_passenger.dart';
import 'package:practice/dashboardpassenger/pass_feedback.dart';
import 'package:practice/dashboardpassenger/pass_notification.dart';
import 'dart:io';
import 'booking_pass.dart';
import 'pass_profile.dart';

class HomeScreen extends StatefulWidget {
  final String welcomeMessage;

  const HomeScreen({super.key, required this.welcomeMessage});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0; // Current selected index

  late List<Widget> _screens;

  @override
  void initState() {
    super.initState();
    _screens = [
      PassengerHomeScreen(welcomeMessage: widget.welcomeMessage),
      PassLocationScreen(
        tripId: '',
      ),
      ExampleScreen(),
      PassprofileScreen(welcomeMessage: widget.welcomeMessage),
    ];
  }

  // Update the current index when a navigation item is tapped
  void _onNavBarTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[
          _currentIndex], // Display the current screen based on selected index
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: Colors.orange,
        unselectedItemColor: Colors.grey,
        onTap: _onNavBarTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.location_on),
            label: 'Location',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications),
            label: 'Notification',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

// Home (Homedriver) Screen
class PassengerHomeScreen extends StatefulWidget {
  final String welcomeMessage;

  const PassengerHomeScreen({super.key, required this.welcomeMessage});

  @override
  _PassengerHomeScreenState createState() => _PassengerHomeScreenState();
}

class _PassengerHomeScreenState extends State<PassengerHomeScreen> {
  File? _profileImage;

  // Method to pick an image from gallery
  Future<void> _pickProfileImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      setState(() {
        _profileImage = File(image.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Passenger Dashboard'),
        backgroundColor: Colors.orange,
      ),
      body: Column(
        children: [
          // Profile Section
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                GestureDetector(
                  onTap: _pickProfileImage,
                  child: CircleAvatar(
                    radius: 50,
                    backgroundImage: _profileImage == null
                        ? const AssetImage(
                            'assets/profile.jpg') // Default image
                        : FileImage(_profileImage!)
                            as ImageProvider<Object>, // Proper casting
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  widget.welcomeMessage, // Display dynamic welcome message
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          // Dashboard Grid Buttons
          Expanded(
            child: GridView.count(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              padding: const EdgeInsets.all(10),
              childAspectRatio: 1.2, // Adjusts the size of each button
              children: [
                _buildGridButton('Ride History', Icons.history, () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PassHistoryScreen(),
                    ),
                  );
                }),
                _buildGridButton('Booked', Icons.book_online, () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => BookPassScreen()),
                  );
                }),
                _buildGridButton('Feedbacks', Icons.feedback, () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            RatingsAndReviewsScreen(driverId: '123')),
                  );
                }),
                _buildGridButton('Settings', Icons.settings, () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => PassengerSettings()),
                  );
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Grid Button Widget for the dashboard options
  Widget _buildGridButton(String title, IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        elevation: 5,
        color: Colors.orange[100],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: Colors.orange),
            const SizedBox(height: 10),
            Text(
              title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}

// Location Screen

// Ride History Screen

// Book Ride Screen

// Earnings Screen

// Feedbacks Screen

// RouteSettings Screen
class PassengerSettings extends StatelessWidget {
  const PassengerSettings({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: const Center(child: Text('Passenger Settings Page')),
    );
  }
}

// Notification Screen

