import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class PassLocationScreen extends StatelessWidget {
  final String tripId; // Pass trip ID if necessary

  const PassLocationScreen({super.key, required this.tripId});

  @override
  Widget build(BuildContext context) {
    // Simulate saving trip data to Firestore
    Future<void> saveTripToHistory() async {
      final tripData = {
        'from': 'Starting Point', // Replace with actual data
        'to': 'Destination', // Replace with actual data
        'date': DateTime.now().toString().split(' ')[0], // Current date
        'time': TimeOfDay.now().format(context), // Current time
        'timestamp': Timestamp.now(),
      };

      try {
        await FirebaseFirestore.instance.collection('tripHistory').add(tripData);
        print('Trip saved to history!');
      } catch (e) {
        print('Failed to save trip: $e');
      }
    }

    // Save trip data as soon as this screen is opened
    saveTripToHistory();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Passenger Location'),
        backgroundColor: Colors.orange,
      ),
      body: Center(
        child: const Text(
          'Showing passenger location...',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
