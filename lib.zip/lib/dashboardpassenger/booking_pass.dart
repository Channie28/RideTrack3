import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'page2_booking.dart';

class BookPassScreen extends StatelessWidget {
  const BookPassScreen({super.key});

  Future<void> addDriverToFeedbackCollection(
      Map<String, dynamic> driver) async {
    try {
      // Add driver's details to the 'feedback' collection
      await FirebaseFirestore.instance.collection('feedback').add({
        'name': driver['name'],
        'profilePic': driver['profileImage'] ?? '',
        'rating': 0, // Default rating (can be updated later)
        'comment': '', // Empty comment (can be updated later)
        'contactNumber': driver['contactNumber'],
        'plateNumber': driver['plateNumber'],
        'isOnline': driver['isOnline'],
      });
    } catch (e) {
      debugPrint('Error adding driver to feedback: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Available Drivers'),
        backgroundColor: Colors.orange,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('drivers')
            .where('isOnline', isEqualTo: true) // Only fetch online drivers
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No online drivers found.'));
          }

          return ListView(
            children: snapshot.data!.docs.map((doc) {
              final driver = doc.data() as Map<String, dynamic>;
              return ListTile(
                leading: CircleAvatar(
                  radius: 30,
                  backgroundImage: driver['profileImage'] != null
                      ? NetworkImage(driver['profileImage'])
                      : const AssetImage('assets/download (1).png')
                          as ImageProvider,
                ),
                title: Text(
                  driver['name'] ?? 'Unknown',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Plate Number: ${driver['plateNumber'] ?? 'N/A'}'),
                    Text('Contact: ${driver['contactNumber'] ?? 'N/A'}'),
                  ],
                ),
                trailing: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                  ),
                  child: const Text('Book'),
                  onPressed: () async {
                    // Add driver to feedback collection
                    await addDriverToFeedbackCollection(driver);

                    // Navigate to the next booking screen
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Paga2Booking(
                          driverName: driver['name'] ?? 'N/A',
                          plateNumber: driver['plateNumber'] ?? 'N/A',
                          contactNumber: driver['contactNumber'] ?? 'N/A',
                          profileImage: driver['profileImage'] ?? '',
                        ),
                      ),
                    );
                  },
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}
